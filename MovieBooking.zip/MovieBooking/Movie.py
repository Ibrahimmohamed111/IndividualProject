class Movie:
    def __init__(self, id, img, title,duration, release_date,place,about, cast,tag_name, price):
        self.id = id
        self.img = img
        self.title = title
        self.duration = duration
        self.release_date = release_date
        self.place = place
        self.about = about
        self.cast = cast
        self.tag_name = tag_name
        self.price = price

