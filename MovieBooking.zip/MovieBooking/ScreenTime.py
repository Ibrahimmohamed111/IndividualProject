class ScreenTime:
    def __init__(self, id, movie_id, screen_name,time):
        self.id = id
        self.movie_id = movie_id
        self.screen_name = screen_name
        temp_list = time.split(",")
        self.times = []
        self.time_list = []
        time_slots = ["9:00 AM","12:00 PM","3:00 PM","6:00 PM","9:00 PM"]
        print ("List of times")
        print(self.time_list)
        for e in temp_list:
            e = int(e)
            self.time_list.append(e)
            self.times.append(time_slots[e-1])

