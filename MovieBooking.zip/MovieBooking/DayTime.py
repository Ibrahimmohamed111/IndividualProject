class DayTime:
    def __init__(self, id,day_id ,day,month):
        self.id = id
        self.day_id = day_id
        self.day = day
        self.month = month


