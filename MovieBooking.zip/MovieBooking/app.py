from flask import Flask, render_template, request, redirect, url_for, session
import pymysql.cursors
from Movie import Movie
from ScreenTime import ScreenTime
from DayTime import DayTime
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = "secret key"

conn = pymysql.connect(host='localhost',
                                 user='root',
                                 password='',
                                 db='movie_ticket_booking',
                                 charset='utf8mb4',
                                 cursorclass=pymysql.cursors.DictCursor,
                                 autocommit=True)


@app.route('/movies')
def movies():
    for key in list(session.keys()):
        session.pop(key)
    session['user_id'] = 1
    sql = "SELECT * FROM movies"
    cursor = conn.cursor()
    cursor.execute(sql)
    rows = cursor.fetchall()
    movies= []
    for row in rows:
        print(row)
        movie = Movie(row['id'], row['img'], row['title'], row['duration'], row['release_date'], row['place'], row['about'], row['casting'], row['tag_name'], row['price'])
        movies.append(movie)
    return render_template("index.html",movies=movies)


@app.route("/book_ticket", methods=['POST'])
def book_ticket():
    movie_id = request.form['movie_id']
    print ("selected movie " +movie_id)
    sql = "SELECT * FROM screen_time where movie_id='" + movie_id + "'"
    cursor = conn.cursor()
    cursor.execute(sql)
    rows = cursor.fetchall()
    session['movie_id'] = movie_id
    screen_times = []
    for row in rows:
        screenTime = ScreenTime(row['id'], row['movie_id'], row['screen_name'], row['time'])
        session['screen_id'] = str(row['screen_name'])
        print (row['time'])
        print ("------------------")
        print(screenTime.time_list)
        screen_times.append(screenTime)

    sql = "SELECT * FROM movies where id='" + movie_id + "'"
    cursor = conn.cursor()
    cursor.execute(sql)
    row = cursor.fetchone()
    session['movie_name'] = row["title"]
    session["price"]  = row["price"]
    session['movie_img'] = row["img"]

    days = []
    date = datetime.today()
    for i in range(7):
        day_id = date.strftime("%d")
        day_name = date.strftime("%A")
        month = date.strftime("%B")[0:3]
        d1 = DayTime(i+1,day_id, day_name, month)
        days.append(d1)
        date += timedelta(days=1)
    return render_template("book_ticket.html",screen_times=screen_times, days=days)

@app.route("/seat_selection")
def seat_selection():
    print("Calling Seat selection.................")
    return render_template("seat_selection.html")

@app.route("/show_ticket")
def show_ticket():
    print("Calling Seat selection.................")
    return render_template("e_ticket.html")

@app.route("/save_time",methods=['POST'])
def save_time():
    print("Calling save time.................")
    data = request.get_json()  # retrieve the data sent from JavaScript
    # process the data using Python code
    result = data['time_slot']
    time_slots = ["9:00 AM", "12:00 PM", "3:00 PM", "6:00 PM", "9:00 PM"]
    session['time_slot'] = time_slots[result]
    print(str(session['time_slot']))
    return ""


@app.route("/get_price",methods=['POST'])
def get_price():
    print("Calling get price.................")
    price = str(session['price'])
    return price

@app.route("/refreshPage",methods=['POST'])
def refreshPage():
    print("Loadinf seat selection.........")
    day_id = session['sel_day_id']
    month = session['sel_month']
    day_name = session['sel_day_name']
    print(str(day_id) + "," + str(month) + "," + str(day_name))
    time_slot = session['time_slot']
    return render_template("seat_selection.html", day_id=day_id, month=month, day_name=day_name, time_slot=time_slot)

@app.route("/save_day",methods=['POST'])
def save_day():
    print("Calling save day.................")
    data = request.get_json()
    result = data['day_id']
    print("Selected day id " + str(result))
    date = datetime.today()
    for i in range(7):
        day_id = date.strftime("%d")
        day_name = date.strftime("%A")
        month = date.strftime("%B")[0:3]
        if i+1 == int(result):
            session['sel_day_id'] = day_id
            session['sel_month'] = month
            session['sel_day_name'] = day_name
            break
        date += timedelta(days=1)
    session['movie_date'] = str(session['sel_day_id']) + " " + session['sel_month'] + str(date.year)
    return ""


@app.route("/add_seat",methods=['POST'])
def add_seat():
    print("Calling add seat.................")
    data = request.get_json()
    seat_id = data['seat_id']
    print("trying to add: " + str(seat_id))
    if session.get('selected_seats1'):
        #if seat_id not in session['selected_seats']:
        slist = session['selected_seats1']
        slist.append(seat_id)
        session['selected_seats1'] = slist
    else:
        print("Creating new list")
        session['selected_seats1'] =  []
        slist = session['selected_seats1']
        slist.append(seat_id)
        session['selected_seats1'] = slist
    print(session['selected_seats1'])
    print("---------------------------")
    return ""

@app.route("/remove_seat",methods=['POST'])
def remove_seat():
    print("Calling remove seat.................")
    data = request.get_json()
    seat_id = data['seat_id']
    print("trying to remove: " + str(seat_id))
    if session.get('selected_seats1'):
        slist = session['selected_seats1']
        id = 0
        found = False
        for entry in slist:
            if entry == seat_id:
                print("Matched...")
                found = True
                break
            id = id + 1
        if found:
            print("Trying to delete " + str(id))
            del slist[id]
            session['selected_seats1'] = slist

    print(session['selected_seats1'])
    print("---------------------------")
    return ""


@app.route("/get_selected_seats", methods=['POST'])
def get_selected_seats():
    seats = ""
    id = 0
    if 'selected_seats1' in session:
        for s in session['selected_seats1']:
            if id == 0:
                seats +=  str(s)
            else:
                seats += ","  + str(s)
            id = id + 1
        print(seats)
    return seats

@app.route("/confirm_payment",methods=['POST'])
def confirm_payment():
    print("Confirm payment called...........")
    seats = ""
    id = 0
    for s in session['selected_seats1']:
        if id == 0:
            seats +=  str(s)
        else:
            seats += ","  + str(s)
        id = id + 1
    print(seats)
    day_id = session['sel_day_id']
    month = session['sel_month']
    day_name = session['sel_day_name']
    movie_id = session['movie_id']
    time_slot = session['time_slot']
    user_id = session['user_id']
    movie_name = session['movie_name']
    cursor = conn.cursor()
    sql = "SELECT * FROM Bookings WHERE day_id=%s AND month=%s AND day_name=%s AND movie_id=%s AND user_id=%s"
    values = (day_id, month,day_name,movie_id,user_id)
    count = cursor.execute(sql, values)
    rows = cursor.fetchone()
    if rows is None:
        sql = "INSERT INTO Bookings (day_id,month,day_name, movie_id,user_id,time_slot, seats) VALUES (%s, %s, %s, %s, %s,%s,%s)"
        val = (day_id, month,day_name,movie_id,user_id, time_slot, seats)
        cursor.execute(sql, val)
        conn.commit()
    else:
        all_seats = rows['seats']
        all_seats += "," + seats
        cursor.execute("UPDATE Bookings SET seats = %s  WHERE day_id=%s and month=%s and day_name=%s and  movie_id=%s and user_id=%s and time_slot=%s",
                       (all_seats,day_id, month,day_name,movie_id,user_id, time_slot))
        conn.commit()
    session['total_price'] = len(session['selected_seats1']) * int(session['price'])

    print ("Total Price " + str(session['total_price']))
    return ""

@app.route("/get_allocated_seats", methods=['POST'])
def get_allocated_seats():
    day_id = session['sel_day_id']
    month = session['sel_month']
    day_name = session['sel_day_name']
    movie_id = session['movie_id']
    time_slot = session['time_slot']
    user_id = session['user_id']
    cursor = conn.cursor()
    sql = "SELECT * FROM Bookings WHERE day_id=%s AND month=%s AND day_name=%s AND movie_id=%s AND user_id=%s AND time_slot=%s"
    values = (day_id, month,day_name,movie_id, user_id, time_slot)
    count = cursor.execute(sql, values)
    rows = cursor.fetchone()
    print("Allocated seat result ")
    print(rows)
    if rows is None:
        return ""
    else:
        return rows['seats']


@app.route("/back_home")
def back_home():
    for key in list(session.keys()):
        session.pop(key)
    session['user_id'] = 1
    sql = "SELECT * FROM movies"
    cursor = conn.cursor()
    cursor.execute(sql)
    rows = cursor.fetchall()
    movies= []
    for row in rows:
        print(row)
        movie = Movie(row['id'], row['img'], row['title'], row['duration'], row['release_date'], row['place'], row['about'], row['casting'], row['tag_name'], row['price'])
        movies.append(movie)
    return render_template("index.html",movies=movies)

@app.route("/contact_us")
def contact_us():
    return render_template("contact.html")


@app.route("/save_feedback", methods=['POST'])
def save_feedback():
    return render_template("contact.html", message="Successfully posted!")

if __name__ == '__main__':
    app.run()
